package com.lab.controller;

import com.lab.dao.productDAO;
import com.lab.model.Product;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "InsertProductServlet", urlPatterns = {"/InsertProductServlet"})
public class InsertProductServlet extends HttpServlet {

    private productDAO dao;

    // initialize DAO
    @Override
    public void init() {
        dao = new productDAO();
    }

    // handle form submit (POST)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ambil data dari form
        String name = request.getParameter("name");
        String category = request.getParameter("category");
        double price = Double.parseDouble(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        // create object
        Product p = new Product(name, category, price, quantity);

        // insert guna DAO
        dao.insertProduct(p);

        // redirect ke list
        response.sendRedirect("ViewProductServlet");
    }

    // optional (tak guna pun sebenarnya)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("add_product.html");
    }

    @Override
    public String getServletInfo() {
        return "Insert Product Servlet";
    }
}